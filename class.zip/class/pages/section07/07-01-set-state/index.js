import BoardWrite from "../../../src/components/units/board/07-write/BoardWrite.container";

export default function GraphqlMutationPage(){
   
    return (
        <BoardWrite/>
    );
}