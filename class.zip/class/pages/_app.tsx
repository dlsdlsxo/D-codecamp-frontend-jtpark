import { ApolloProvider, ApolloClient, InMemoryCache } from "@apollo/client";
import type { AppProps } from "next/app";
// import { AppProps } from 'next/app'

export default function App({ Component, pageProps }: AppProps): JSX.Element {
  const client = new ApolloClient({
    // 주소 등록
    uri: "http://example.codebootcamp.co.kr/graphql",
    cache: new InMemoryCache(), // 컴퓨터 메모리 -- Backend 데이터 받아올 때, 변수 넣어주기 전에 임시적으로 공간 만들 때 관련
  });

  return (
    <ApolloProvider client={client}>
      <Component {...pageProps} />
    </ApolloProvider>
  );
}
