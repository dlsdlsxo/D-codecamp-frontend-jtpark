import { gql, useMutation, useQuery } from "@apollo/client";
import { Fragment } from "react";

const FETCH_BOARDS = gql`
    query{
        fetchBoards{
            number
            writer
            title
            contents
        }
    }
`
const DELETE_BOARD = gql`
    mutation deleteBoard($number: Int){
        deleteBoard(number: $number){
            message
        }
    }
`

export default function GraphqlMutationPage(){

    const {data} = useQuery(FETCH_BOARDS);
    console.log(data?.fetchBoards);

    const [deleteBoard] = useMutation(DELETE_BOARD);

    const onClickDelete = (event) => {
        deleteBoard({
            variables:{number: Number(event.target.id)},
            refetchQueries: [{query: FETCH_BOARDS}]
        })
    }
    return (
        <div>
            {/* //특별한 이유가 없으면? Fragment로 감싸자! <div>는 1개 더 그려야되서 조금 느려짐  */}
            {data?.fetchBoards.map((el,index) => (
                //1. 프레그먼트란? <></>, <Fragment></Fragment>
                <Fragment key={el.number}>
                    <span>
                        <input type="checkbox"/>
                    </span>
                    <span style={{margin: "10px"}}>{el.number}</span>
                    <span style={{margin: "10px"}}>{el.title}</span>
                    <span style={{margin: "10px"}}>{el.writer}</span>
                    <span>
                        <button id={el.number} onClick={onClickDelete} >삭제</button>
                    </span>
                </Fragment>
            ))}
        </div>
    );
}