import BoardWrite from "../../../../src/components/units/board/write/BoardWrite.container";

export default function BoardsEditPage() {
  return <BoardWrite isEdit={true} />;
}
