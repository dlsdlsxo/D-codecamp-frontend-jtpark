import BoardList from '../../src/components/units/board/list/BoardList.container'

export default function BoardsPage(){
    return <BoardList />
}