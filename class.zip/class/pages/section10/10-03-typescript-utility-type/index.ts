export interface IProfile {
    name: string
    age: number
    school : string
    hobby? : string
}

// 1. Partial 타입
type IProfile2 = Partial<IProfile>
// interface IProfile2 {
//     name?: string
//     age?: number
//     school? : string
//     hobby? : string
// }

// 2. Required 타입
type IProfile3 = Required<IProfile>
// interface IProfile3 {
//     name: string
//     age: number
//     school : string
//     hobby : string
// }

// 3. Pick 타입
type IProfile4 = Pick<IProfile,"name" | "age">
// interface IProfile4 {
//     name: string
//     age: number
// }

// 4. Omit 타입
type IProfile5 = Omit<IProfile,"school">
// interface IProfile5 {
//     name: string
//     age: number
//     hobby : string
// }

// 5. Record 타입
type eee = "철수" | "영희" | "훈이" // Union 타입
let child1:eee = "영희" //철수,영희,훈이만 도미
let child2:string = "sssss"

type fff = Record<eee,IProfile>
// 6. 객체의 키들로 Union 타입
type ggg = keyof IProfile //key들만 모아 Union 타입

let myprofile:ggg = "age"

// 7. type vs interface 차이 => 선언병합 interface만 가능
export interface IProfile{
    candy: number // 선언병합으로 추가됨
}

