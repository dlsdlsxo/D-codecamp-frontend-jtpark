import BoardWrite from "../../../src/components/units/board/10-write/BoardWrite.container";

export default function BoardsNewPage() {
  return <BoardWrite isEdit={false} />
}
