import { gql, useQuery } from '@apollo/client';
import {useRouter} from 'next/router'

const FETCH_BOARD = gql`
    query fetchBoard($number: Int){
        fetchBoard(number: $number){
            number
            writer
            title
            contents
        }
    }
`

export default function DynamicRoutingPage(){
    const router = useRouter();


    const {data} = useQuery(FETCH_BOARD,{
        variables: {number: Number(router.query.qqq)}
    });
    
    return (<div>
                <div>{router.query.qqq}</div>
            </div>
    )
}