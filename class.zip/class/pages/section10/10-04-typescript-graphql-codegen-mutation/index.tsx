import { gql,useMutation } from "@apollo/client";

const CREATE_BOARD =  gql`
    mutation createBoard($writer: String,$title: String,$contents:String){
        createBoard(writer:$writer,title:$title, contents:$contents){
            _id
            number
            message
        }
    }
`;

export default function GraphqlMutationPage(){
    // const [writer,setWriter] = useState<string|number| undefined>("");
    // const [나의함수] = useMutation<결과타입,변수타입>(CREATE_BOARD);
    const [나의함수] = useMutation<Pick<IMutation,"createBoard">,IMutationCreateBoardArgs>(CREATE_BOARD);

    const onClickSubmit = async () => {
        const result = await 나의함수({
            variables:{ //$:{ variables 이게 $ 역할을 함
                writer:"훈이",
                title:"안녕하세요.",
                contents:"반갑습니다."
            }
        });
        
    }

    return (
        <button onClick={onClickSubmit}>GRAPHQL-API 요청하기</button>
    );
}