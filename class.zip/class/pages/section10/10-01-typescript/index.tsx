export default function TypescriptPage(){
    //타입추론 처음 값이 들어가면 추론 가능
    let aaa = "안녕하세요"
    
    //aaa =3 에러 발생.

    //타입 명시 
    let bbb:string = "반값습니다."
    //bbb = 10

    //타입 명시가 필요한 상황
    let ccc:number |string = 1000
    ccc = "1000원"

    //숫자 타입
    let ddd:number = 10
    //ddd = "철수"
    
    // 블린타입
    let eee:boolean = true
    eee = false
    // eee = "false" // true

    //배열 타입
    let fff:number[] = [1,2,3]
    //fff = ["sss"]
    let ggg:string[] = ["1","2","3"] 
    let hhh = ["철수","영희",10] //(string | number)[]

    //객체 타입


    const profile = {
        name:"철수",
        age:8,
        school:"다람쥐초등학교"
    }
    profile.name = "훈희" //타입 추론으로 이것만 가능
    // profile.age = "8살"
    //profile.hobby = "수영"

    interface IProfile2 {
        name: string
        age: number | string
        school: string
        hobby?: string
    }

    const profile2:IProfile2 = {
        name:"철수",
        age:8,
        school:"다람쥐초등학교"
    }
    profile2.name = "훈희"
    profile2.age = "8살"
    profile2.hobby = "수영"

    // 함수 타입
    function add(num1:number,num2:number,unit:string):string {
        return num1+num2+unit
    }

    const result = add(1000,2000,"원")

    const add2 = (num1:number,num2:number,unit:string):string => {
        return num1+num2+unit
    }

    const result2 = add2(1000,2000,"원")

    // any타입 => JS
    let qqq:any = "철수" 
    qqq = 123
    qqq = true

    

    return <></>;
}