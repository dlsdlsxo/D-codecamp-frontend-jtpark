import {  useState ,ChangeEvent} from "react";
import { useMutation } from '@apollo/client'
import { useRouter } from 'next/router'
import BoardWriteUI from './BoardWrite.presenter'
import { CREATE_BOARD, UPDATE_BOARD } from './BoardWrite.queries'

interface IBoardWriteProps{
  isEdit:boolean
  data?:any
}

export default function BoardWrite(props:IBoardWriteProps){
  const router = useRouter()
  const [isActive, setIsActive] = useState(false);

  const [writer, setWriter] = useState("");
  const [password, setPassword] = useState("");
  const [title, setTitle] = useState("");
  const [contents, setContents] = useState("");

  const [writerError, setWriterError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [titleError, setTitleError] = useState("");
  const [contentsError, setContentsError] = useState("");

  const [createBoard] = useMutation(CREATE_BOARD)
  const [updateBoard] = useMutation(UPDATE_BOARD);

  const onChangeWriter = (event : ChangeEvent<HTMLInputElement>) => {
    setWriter(event.target.value);
    if(event.target.value !== ""){
      setWriterError("")
    }

    if (event.target.value && password && title && contents) {
      setIsActive(true);
    } else {
      setIsActive(false);
    }
  };

  const onChangePassword = (event : ChangeEvent<HTMLInputElement>) => {
    setPassword(event.target.value);
    if(event.target.value !== ""){
      setPasswordError("")
    }

    if (writer && event.target.value && title && contents) {
      setIsActive(true);
    } else {
      setIsActive(false);
    }
  };

  const onChangeTitle = (event : ChangeEvent<HTMLInputElement>) => {
    setTitle(event.target.value);
    if(event.target.value !== ""){
      setTitleError("")
    }

    if (writer && password && event.target.value && contents) {
      setIsActive(true);
    } else {
      setIsActive(false);
    }
  };

  const onChangeContents = (event : ChangeEvent<HTMLTextAreaElement>) => {
    setContents(event.target.value);
    if(event.target.value !== ""){
      setContentsError("")
    }

    if (writer && password && title && event.target.value) {
      setIsActive(true);
    } else {
      setIsActive(false);
    }
  };

  const onClickSubmit = async () => {
    if (!writer) {
      setWriterError("작성자를 입력해주세요.");
    }
    if (!password) {
      setPasswordError("비밀번호를 입력해주세요.");
    }
    if (!title) {
      setTitleError("제목을 입력해주세요.");
    }
    if (!contents) {
      setContentsError("내용을 입력해주세요.");
    }
    if (writer && password && title && contents) {
      try {
        const result = await createBoard({
          variables: {
            createBoardInput: {
              writer,
              password,
              title,
              contents
            }
          }
        })
        console.log(result.data.createBoard._id)
        router.push(`/boards/${result.data.createBoard._id}`)
      } catch(error) {
        alert(error.message)
      }
    }
  };

  const onClickUpdate = async () => {
    try {

      interface IUpdateBoardInput {
        title: string
        contents: string
      }
      interface IMyVariables {
        boardId : string | string[] | undefined
        password : string
        updateBoardInput: IUpdateBoardInput
      }

      const myVariables:IMyVariables = {
        boardId: router.query.boardId,
        password,
        updateBoardInput: {
          title,
          contents
        },
      };

      const result = await updateBoard({
        variables: myVariables,
      })
      router.push(`/boards/${result.data.updateBoard._id}`)
    } catch(error) {
      alert(error.message)
    }
  };

  return (
    <BoardWriteUI
          passwordError={passwordError}
          writerError={writerError}
          titleError={titleError}
          contentsError={contentsError}
          onChangeWriter={onChangeWriter}
          onChangePassword={onChangePassword}
          onChangeTitle={onChangeTitle}
          onChangeContents={onChangeContents}
          onClickSubmit={onClickSubmit}
          onClickUpdate={onClickUpdate}
          isActive={isActive}
          isEdit={props.isEdit}
    />
  )
}