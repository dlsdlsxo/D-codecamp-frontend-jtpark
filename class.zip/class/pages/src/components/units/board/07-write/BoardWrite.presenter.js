import { BlueButton, RedInput } from "./BoardWrite.style";

export default function BoardWriteUI(props){


    return (
        <div>
            작성자: <RedInput type="text"  onChange={props.bb} />
            제목 : <input type="text" onChange={props.cc} />
            내용 : <input type="text" onChange={props.dd} />
            <BlueButton 
                onClick={props.aa}
                buttonColor="yellow"
            >
                GRAPHQL-API 요청하기
            </BlueButton>
        </div>
    );
}